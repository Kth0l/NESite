import base64
import json
import requests
import subprocess

DATABASE_FILE = 'users.json'
DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/1380930267929120808/8Okk4qSleXuUHQUO6gC8wTmHuG5flIQjMiU311HPDz02n0j118RkS6w5lBzq5jyv7pJf'  # coloque seu webhook Discord aqui

def load_users():
    try:
        with open(DATABASE_FILE, 'r') as f:
            content = f.read().strip()
            if not content:
                return {}
            return json.loads(content)
    except (FileNotFoundError, json.JSONDecodeError):
        return {}

def save_users(users):
    with open(DATABASE_FILE, 'w') as f:
        json.dump(users, f)

def encode_password(password):
    encoded_bytes = base64.b64encode(password.encode('utf-8'))
    return encoded_bytes.decode('utf-8')

def send_discord_message(message):
    data = {"content": message}
    try:
        requests.post(DISCORD_WEBHOOK_URL, json=data)
    except Exception as e:
        print(f"Warning: Could not send Discord message: {e}")

def register():
    users = load_users()
    username = input("Create your username: ")
    if username in users:
        print("Username already exists.")
        return
    password = input("Create your password: ")
    encoded_password = encode_password(password)
    users[username] = encoded_password
    save_users(users)
    print("User registered successfully.")
    send_discord_message(f"New user registered: {username}")

def login():
    users = load_users()
    username = input("Username: ")
    password = input("Password: ")
    encoded_password = encode_password(password)
    if username in users and users[username] == encoded_password:
        print("Login successful.")
        send_discord_message(f"User logged in: {username}")
        return username
    else:
        print("Invalid username or password.")
        return None

def send_command_to_backend(user, command):
    url = 'http://localhost:3000/send-command'  # backend deve rodar aqui
    data = {'user': user, 'command': command}
    try:
        r = requests.post(url, json=data)
        if r.status_code == 200:
            print("Command sent successfully!")
        else:
            print("Failed to send command.")
    except Exception as e:
        print(f"Error sending command: {e}")

def command_prompt(username):
    print(f"Welcome, {username}! Enter your commands below.")
    while True:
        cmd = input("> ")
        if cmd.lower() in ['exit', 'quit']:
            print("Exiting terminal.")
            break
        send_command_to_backend(username, cmd)

def main():
    while True:
        print("1 - Register")
        print("2 - Login")
        print("3 - Exit")
        choice = input("Choose an option: ")
        if choice == '1':
            register()
        elif choice == '2':
            user = login()
            if user:
                command_prompt(user)
        elif choice == '3':
            break
        else:
            print("Invalid option.")

if __name__ == "__main__":
    main()

if __name__ == '__main__':
    main()