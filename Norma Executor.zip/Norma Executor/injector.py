import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import tkinter.font as tkfont
import requests
import re

LUA_KEYWORDS = [
    "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
    "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
    "true", "until", "while", "local", "function"
]

class RobloxCodeInjector(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Roblox Code Injector")
        self.geometry("900x650")
        self.configure(bg="#1e1e2f")

        # Fonte itálica para comentários
        self.comment_font = tkfont.Font(family="Consolas", size=11, slant="italic")

        self.create_widgets()
        self.autocomplete_window = None

    def create_widgets(self):
        top_frame = tk.Frame(self, bg="#2d2d44", padx=10, pady=10)
        top_frame.pack(fill=tk.X)

        tk.Label(top_frame, text="Username:", font=("Segoe UI", 12), fg="white", bg="#2d2d44").pack(side=tk.LEFT)
        self.entry_user = tk.Entry(top_frame, font=("Segoe UI", 12), width=25)
        self.entry_user.pack(side=tk.LEFT, padx=(5, 20))

        btn_new = tk.Button(top_frame, text="New Script", command=self.new_script, bg="#007acc", fg="white")
        btn_new.pack(side=tk.LEFT, padx=5)
        btn_open = tk.Button(top_frame, text="Open Script", command=self.open_script, bg="#007acc", fg="white")
        btn_open.pack(side=tk.LEFT, padx=5)
        btn_save = tk.Button(top_frame, text="Save Script", command=self.save_script, bg="#007acc", fg="white")
        btn_save.pack(side=tk.LEFT, padx=5)
        btn_inject = tk.Button(top_frame, text="Inject Code", command=self.send_code, bg="#007acc", fg="white")
        btn_inject.pack(side=tk.LEFT, padx=5)

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(expand=True, fill=tk.BOTH, padx=10, pady=10)

        self.new_script()

        style = ttk.Style()
        style.theme_use('default')
        style.configure('TNotebook.Tab', background="#444466", foreground='white', padding=[10, 5])
        style.map('TNotebook.Tab', background=[('selected', '#007acc')], foreground=[('selected', 'white')])

    def new_script(self):
        frame = tk.Frame(self.notebook, bg="#1e1e2f")
        editor = tk.Text(frame, font=("Consolas", 11), bg="#1e1e2f", fg="#d4d4d4", insertbackground="white", undo=True)
        editor.pack(expand=True, fill=tk.BOTH)
        editor.bind('<KeyRelease>', self.on_key_release)
        editor.bind('<Control-space>', self.show_autocomplete)

        editor.tag_configure("keyword", foreground="#569CD6")
        editor.tag_configure("string", foreground="#D69D85")
        editor.tag_configure("comment", foreground="#6A9955", font=self.comment_font)

        self.notebook.add(frame, text="New Script")
        self.notebook.select(frame)

    def open_script(self):
        path = filedialog.askopenfilename(filetypes=[("Lua Files", "*.lua"), ("All Files", "*.*")])
        if path:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    content = f.read()
                frame = tk.Frame(self.notebook, bg="#1e1e2f")
                editor = tk.Text(frame, font=("Consolas", 11), bg="#1e1e2f", fg="#d4d4d4", insertbackground="white", undo=True)
                editor.pack(expand=True, fill=tk.BOTH)
                editor.insert("1.0", content)
                editor.bind('<KeyRelease>', self.on_key_release)
                editor.bind('<Control-space>', self.show_autocomplete)

                editor.tag_configure("keyword", foreground="#569CD6")
                editor.tag_configure("string", foreground="#D69D85")
                editor.tag_configure("comment", foreground="#6A9955", font=self.comment_font)

                self.notebook.add(frame, text=path.split("/")[-1])
                self.notebook.select(frame)
                self.highlight_syntax(editor)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to open file: {e}")

    def save_script(self):
        current = self.notebook.select()
        if not current:
            messagebox.showwarning("Warning", "No script open to save.")
            return

        frame = self.nametowidget(current)
        editor = frame.winfo_children()[0]
        code = editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showwarning("Warning", "Script is empty.")
            return

        path = filedialog.asksaveasfilename(defaultextension=".lua",
                                            filetypes=[("Lua files", "*.lua"), ("All files", "*.*")])
        if path:
            try:
                with open(path, 'w', encoding='utf-8') as f:
                    f.write(code)
                messagebox.showinfo("Success", f"Script saved to {path}")
                filename = path.split("/")[-1]
                self.notebook.tab(current, text=filename)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save file: {e}")

    def send_code(self):
        user = self.entry_user.get().strip()
        if not user:
            messagebox.showerror("Error", "Please enter your username.")
            return

        current = self.notebook.select()
        if not current:
            messagebox.showerror("Error", "No script open to inject.")
            return

        frame = self.nametowidget(current)
        editor = frame.winfo_children()[0]
        code = editor.get("1.0", tk.END).strip()
        if not code:
            messagebox.showerror("Error", "Script is empty.")
            return

        url = 'http://localhost:3000/send-command'  # Ajuste para seu backend
        data = {'user': user, 'command': code}

        try:
            response = requests.post(url, json=data)
            if response.status_code == 200:
                messagebox.showinfo("Success", "Code injected successfully!")
            else:
                messagebox.showerror("Failed", "Failed to inject code.")
        except Exception as e:
            messagebox.showerror("Error", f"Error sending code: {e}")

    def on_key_release(self, event):
        editor = event.widget
        self.highlight_syntax(editor)

    def highlight_syntax(self, editor):
        code = editor.get("1.0", tk.END)
        editor.tag_remove("keyword", "1.0", tk.END)
        editor.tag_remove("string", "1.0", tk.END)
        editor.tag_remove("comment", "1.0", tk.END)

        # Comments (--)
        for match in re.finditer(r'--.*', code):
            start = f"1.0+{match.start()}c"
            end = f"1.0+{match.end()}c"
            editor.tag_add("comment", start, end)

        # Strings ("..." or '...')
        for match in re.finditer(r'(\".*?\"|\'.*?\')', code):
            start = f"1.0+{match.start()}c"
            end = f"1.0+{match.end()}c"
            editor.tag_add("string", start, end)

        # Keywords (whole words)
        for keyword in LUA_KEYWORDS:
            for match in re.finditer(r'\b' + re.escape(keyword) + r'\b', code):
                start = f"1.0+{match.start()}c"
                end = f"1.0+{match.end()}c"
                editor.tag_add("keyword", start, end)

    def show_autocomplete(self, event):
        editor = event.widget
        cursor_index = editor.index(tk.INSERT)
        line_start = editor.index(f"{cursor_index} linestart")
        text_before_cursor = editor.get(line_start, cursor_index)

        # pegar a palavra parcial que está antes do cursor
        match = re.search(r"(\w+)$", text_before_cursor)
        if not match:
            self.close_autocomplete()
            return
        prefix = match.group(1).lower()

        suggestions = [kw for kw in LUA_KEYWORDS if kw.startswith(prefix)]
        if not suggestions:
            self.close_autocomplete()
            return

        # cria ou atualiza janela autocomplete
        if self.autocomplete_window is None or not self.autocomplete_window.winfo_exists():
            self.autocomplete_window = tk.Toplevel(self)
            self.autocomplete_window.wm_overrideredirect(True)
            self.autocomplete_window.configure(bg="#2d2d44")

            self.listbox = tk.Listbox(self.autocomplete_window, bg="#1e1e2f", fg="white", highlightthickness=0,
                                      selectbackground="#007acc", activestyle="none", font=("Consolas", 11))
            self.listbox.pack()

            self.listbox.bind("<<ListboxSelect>>", self.insert_autocomplete)
            self.listbox.bind("<Escape>", lambda e: self.close_autocomplete())
            self.listbox.bind("<Return>", self.insert_autocomplete)
            self.listbox.bind("<Double-Button-1>", self.insert_autocomplete)
        else:
            self.listbox.delete(0, tk.END)

        for s in suggestions:
            self.listbox.insert(tk.END, s)

        # posiciona janela autocomplete abaixo do cursor
        bbox = editor.bbox(tk.INSERT)
        if bbox:
            x, y, width, height = bbox
            x_root = editor.winfo_rootx() + x
            y_root = editor.winfo_rooty() + y + height
            self.autocomplete_window.geometry(f"+{x_root}+{y_root}")

        self.listbox.focus_set()

    def insert_autocomplete(self, event):
        if not self.listbox.curselection():
            return
        selection = self.listbox.get(self.listbox.curselection())

        editor = self.notebook.nametowidget(self.notebook.select()).winfo_children()[0]
        cursor_index = editor.index(tk.INSERT)
        line_start = editor.index(f"{cursor_index} linestart")
        text_before_cursor = editor.get(line_start, cursor_index)

        # remove a palavra incompleta
        new_text_before = re.sub(r"(\w+)$", "", text_before_cursor)
        line_end = editor.index(f"{cursor_index} lineend")
        text_after_cursor = editor.get(cursor_index, line_end)

        editor.delete(line_start, line_end)
        editor.insert(line_start, new_text_before + selection + text_after_cursor)
        editor.mark_set(tk.INSERT, f"{line_start}+{len(new_text_before + selection)}c")

        self.close_autocomplete()

    def close_autocomplete(self):
        if self.autocomplete_window and self.autocomplete_window.winfo_exists():
            self.autocomplete_window.destroy()
        self.autocomplete_window = None

if __name__ == "__main__":
    app = RobloxCodeInjector()
    app.mainloop()